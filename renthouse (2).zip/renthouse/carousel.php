
  <div id="myCarousel" class="carousel slide" data-ride="carousel">
    <ol class="carousel-indicators">
      <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
    </ol>
    <div class="carousel-inner">
      <div class="item active">
        <img src="images/carousel.png" alt="RentHouse" style="width:100%; height: 50%;">
      </div>
    </div>
  </div>